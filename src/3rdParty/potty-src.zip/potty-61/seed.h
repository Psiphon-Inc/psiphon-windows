typedef struct obstruct {
	void *ptr;
	int len;
}